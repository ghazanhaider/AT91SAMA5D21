The skin images can be customized, but there are several limitations:

background.png - must be 640x480 image with 24bit RGB colors.
font.png       - must be 128x160 8bit grayscale image.
selector.png   - must be 8x10 8bit grayscale image.

Font and selector colors can be changed by editing skin.txt.

